﻿using System;
using System.Windows.Forms;

namespace Simple_Calculator
{
    public partial class background : Form
    {

        double result = 0;
        string operation = "";
        bool entervalue = false;
        public background()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void buttonclick(object sender, EventArgs e)
        {

            if (textBox1.Text == "0")
                textBox1.Text = "";
           // entervalue = false;
            Button num = (Button)sender;
            if (num.Text == ".")
            {
                if (!textBox1.Text.Contains("."))
                    textBox1.Text = textBox1.Text + num.Text;
            }
            else
                textBox1.Text = textBox1.Text + num.Text;
        }

        private void txtdisplay(object sender, EventArgs e)
        {

        }

        private void operations(object sender, EventArgs e)
        {
            Button num = (Button)sender;
            operation = num.Text;
            result = Double.Parse(textBox1.Text);
            textBox1.Text = "";
            clear.Text = System.Convert.ToString(result) + " " + operation;
           
        }

        private void button12_Click(object sender, EventArgs e)
        {
            textBox1.Text = "0";
            clear.Text = "";
        }

        private void button18_Click(object sender, EventArgs e)
        {
            clear.Text = "";
            switch (operation)
            {
                case "+":
                    textBox1.Text = (result + Double.Parse(textBox1.Text)).ToString();
                    break;
                case "-":
                    textBox1.Text = (result - Double.Parse(textBox1.Text)).ToString();
                    break;
                case "*":
                    textBox1.Text = (result * Double.Parse(textBox1.Text)).ToString();
                    break;
                case "/":
                    textBox1.Text = (result / Double.Parse(textBox1.Text)).ToString();
                    break;
                case "mod":
                    textBox1.Text = (result % Double.Parse(textBox1.Text)).ToString();
                    break;
                case "exp":
                    double i =  Double.Parse(textBox1.Text);
                    double q;
                    q = (result);
                    textBox1.Text = Math.Exp(i * Math.Log(q * 4)).ToString();
                    break;

            }
        }

        private void button13_Click(object sender, EventArgs e)
        {
           
            if (textBox1.Text.Length > 0)
            {
                textBox1.Text = textBox1.Text.Remove(textBox1.Text.Length - 1, 1);
            }
            
            
        }

        private void background_Load(object sender, EventArgs e)
        {

        }

        private void mod_Click(object sender, EventArgs e)
        {
            string[] s = textBox1.Text.ToString().Split('%');
            int n = 0;
            if (textBox1.Text.ToString().Contains("%"))
            {

                n = Convert.ToInt32(s[0].ToString()) % Convert.ToInt32(s[1].ToString());
            }
            textBox1.Text = n.ToString();
        }
    }
}
